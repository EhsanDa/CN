import socket
import threading
import random
import json

def parse_message(message):
    """Parses a message and extracts its components."""
    return json.loads(message)

class GameServer:
    def __init__(self, host="127.0.0.1", port=65432):
        self.server_address = (host, port)
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.ready_players = []
        self.lock = threading.Lock()

    def start(self):
        self.server_socket.bind(self.server_address)
        self.server_socket.listen(5)
        print(f"Server started at {self.server_address}")
        
        while True:
            client_socket, client_address = self.server_socket.accept()
            print(f"Connection from {client_address}")
            threading.Thread(target=self.handle_client, args=(client_socket,)).start()

    def handle_client(self, client_socket):
        try:
            while True:
                message = client_socket.recv(1024).decode("utf-8").strip()
                if not message:
                    break
                
                print(f"Received: {message}")
                print(parse_message(message))
                payload = parse_message(message)['payload']
                response = self.process_message(payload)
                client_socket.sendall(response.encode("utf-8"))
        except ConnectionError:
            print("Client disconnected")
        finally:
            client_socket.close()

    def process_message(self, payload):
        if payload['action'] == "start game":
            with self.lock:
                self.ready_players.append(threading.current_thread().name)
            return "Player added to ready_players"

        elif payload['action'] == "get ready players":
            with self.lock:
                return f"Ready players: {', '.join(self.ready_players)}"

        elif payload['action'] == "roll dice":
            dice_roll = random.randint(1, 6)
            return f"You rolled a {dice_roll}"

        else:
            return "Unknown command"

if __name__ == "__main__":
    server = GameServer()
    server.start()
