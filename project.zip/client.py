from utils.handshake import *
from utils.keyReader import *
from utils.sendmessage import *

handshake()

def start_client():
    while True:
        message = input("Enter your message (start game, I'm ready to game, roll dice, or exit to leave): ").lower()
    
        if message.lower() == "exit":
            break
        if message.lower() == "start game":
            name = input("Enter your Name: ").lower()
            ip = input("Enter your IP: ").lower()
            
        x = {
            "name": name,
            "ip": ip,
            "command": message
        }

        # convert into JSON:
        y = json.dumps(x)
        
        print(y)
        print(type(y))
        
        send_message(y)

if __name__ == "__main__":
    start_client()